# Silverwolf-Bot

A discord bot for Honkai Star Rail, it acts as a database of information about playable characters from the game.
